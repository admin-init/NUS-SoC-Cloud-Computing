# Ticketing System

Deploy with Kubernetes + Flask + Redis + MySQL.
